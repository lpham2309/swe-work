package jrails;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import books.BookView;
import books.Book;
import jrails.View;


import static jrails.View.*;
import static org.hamcrest.Matchers.isEmptyString;
import static org.junit.Assert.*;

public class ViewTest {

    @Test
    public void empty() {
        assertThat(View.empty().toString(), isEmptyString());
    }

    @Test
    public void test_book_view() {
        Html html_1 = new Html();
        String s1 = html_1.div(html_1.strong(html_1.t("Hello World"))).toString();
        System.out.print(s1.equals("<div><b>Hello World</b></div>"));
        assertEquals(s1, "<div><b>Hello World</b></div>");

        Html html_2 = new Html();
        String s2 = html_2.textarea("title", html_2.t("Old Title")).toString();
        assertEquals(s2, "<textarea name=\"title\">Old Title</textarea>");

//        View view = new View();
        String s3 = View.p(View.t("Example view")).toString();
        assert(s3.equals("<p>Example view</p>"));

//        assertEquals(res, "<tr><td><a href=/destroy?id=1>Delete</a></td></tr>");
    }
    @Test
    public void test_show() {
        Html table_body = View.empty();
        table_body =
                table_body.tr(td(t("Title 1")).
                        td(t("Author 1")).
                        td(t(1)).
                        td(link_to("Show", "/show?id=" + 1)).
                        td(link_to("Edit", "/edit?id=" + 1)).
                        td(link_to("Delete", "/destroy?id=" + 1)));

        String test = table_body.toString();
        System.out.println(test);
    }

    @Test
    public void test_html_tags() {
        Html html_3 = new Html();
        String res = html_3.p(strong(t("Title:")).t("Programming Languages: Build, Prove, and Compare")).
                p(strong(t("Author:")).t("Norman Ramsey")).
                p(strong(t("Copies:")).t(999)).
                t(link_to("Edit", "/edit?id=" + 1)).t(" | ").
                t(link_to("Back", "/")).toString();
    }

    @Test
    public void test_br(){
        String s = View.br().toString();
        System.out.println(s);
    }

    @Test
    public void test_new() {
        String s = View.div(t("Title").textarea("title", t("Title"))).toString();
        System.out.println(s);
    }

    @Test
    public void test_show_route() {
        Html s = p(strong(t("Title:")).t("Title 1")).
                p(strong(t("Author:")).t("Author 1")).
                p(strong(t("Copies:")).t(1)).
                t(link_to("Edit", "/edit?id=" + 1)).t(" | ").
                t(link_to("Back", "/"));

        System.out.println(s.toString());
    }

    private static Html the_form(String action, Book b) {
        return form(action,
                div(t("Title").textarea("title", t(b.title))).
                        div(t("Author").textarea("author", t(b.author))).
                        div(t("Copies").textarea("num_copies", t(b.num_copies))).
                        div(submit("Save")));
    }

    @Test
    public void test_new_view() {
        Book a = new Book();
        a.title = "Book 1";
        a.author = "Author 1";
        a.num_copies = 1;
        String s = h1(t("New Book")).seq(the_form("/create", a)).toString();
        System.out.println(s);
    }
}