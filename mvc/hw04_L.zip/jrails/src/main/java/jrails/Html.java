package jrails;

import java.util.ArrayList;
import java.util.List;
public class Html {
    private Object curr_html = "";
    List<String> elements = new ArrayList<>();

    public String toString() {
        String res = "";
        for(String s : elements){
            res += s;
        }
        return res;
    }

    public Html seq(Html h) {

        elements.add(h.toString());
        return this;
    }

    public Html br() {
        elements.add("<br/>");
        return this;
    }

    public Html t(Object o) {
        elements.add(o.toString());
        return this;
    }

    public Html p(Html child) {

        String ret = "<p>" + child.toString() + "</p>";
        elements.add(ret);
        return this;
    }

    public Html div(Html child) {
        elements.add("<div>" + child.toString() + "</div>");
        return this;
    }

    public Html strong(Html child) {
        elements.add("<strong>" + child.toString() + "</strong>");

        return this;
    }

    public Html h1(Html child) {
        elements.add("<h1>" + child.toString() + "</h1>");
        return this;
    }

    public Html tr(Html child) {
        elements.add("<tr>" + child.toString() + "</tr>");
        return this;

    }

    public Html th(Html child) {
        elements.add("<th>" + child.toString() + "</th>");
        return this;
    }

    public Html td(Html child) {
        elements.add("<td>" + child.toString() + "</td>");
        return this;
    }

    public Html table(Html child) {
        elements.add("<table>" + child.toString() + "</table>");
        return this;
    }

    public Html thead(Html child) {
        elements.add("<thead>" + child.toString() + "</thead>");
        return this;
    }

    public Html tbody(Html child) {
        elements.add("<tbody>" + child.toString() + "</tbody>");
        return this;
    }

    public Html textarea(String name, Html child) {
        elements.add("<textarea name=\"" + name + "\">" + child.toString() + "</textarea>");
        return this;
    }

    public Html link_to(String text, String url) {
        elements.add("<a href=\"" + url + "\"" + ">" + text + "</a>");
        return this;
    }

    public Html form(String action, Html child) {
        elements.add("<form action=\"" + action + "\" accept-charset=\"UTF-8\" method=\"post\">" +
                child.toString() +"</form>");
        return this;
    }

    public Html submit(String value) {
        elements.add("<input type=\"submit\" value=\"" + value + "\"/>");
        return this;
    }
}